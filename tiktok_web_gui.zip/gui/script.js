function log(message) {
  const box = document.getElementById("log");
  const time = new Date().toLocaleTimeString();
  box.textContent += `\n[${time}] ${message}`;
  box.scrollTop = box.scrollHeight;
}

async function loadAccounts() {
  const res = await fetch("/api/accounts");
  const data = await res.json();
  const select = document.getElementById("account");

  Object.entries(data).forEach(([key, name]) => {
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = `${key}. ${name}`;
    select.appendChild(opt);
  });
}

async function loadTopics() {
  const res = await fetch("/api/topics");
  const data = await res.json();
  const select = document.getElementById("topic");

  data.forEach((topic) => {
    const opt = document.createElement("option");
    opt.value = topic;
    opt.textContent = topic;
    select.appendChild(opt);
  });
}

async function loadStats() {
  const topic = document.getElementById("topic").value;

  if (!topic) return;

  const res = await fetch(`/api/stats?topic=${encodeURIComponent(topic)}`);
  const data = await res.json();

  document.getElementById("videosCount").textContent = data.videos;
  document.getElementById("pendingCount").textContent = data.pending;
  document.getElementById("uploadedCount").textContent = data.uploaded;
}

async function startBot() {
  const account = document.getElementById("account").value;
  const topic = document.getElementById("topic").value;
  const wait_seconds = document.getElementById("wait").value;

  const res = await fetch("/api/start", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({account, topic, wait_seconds})
  });

  const data = await res.json();

  if (data.ok) {
    log(data.message);
  } else {
    log(`Lỗi: ${data.message}`);
    alert(data.message);
  }

  loadStats();
}

async function stopBot() {
  const res = await fetch("/api/stop", {method: "POST"});
  const data = await res.json();

  if (data.ok) {
    log(data.message);
  } else {
    log(`Lỗi: ${data.message}`);
  }
}

loadAccounts();
loadTopics();
setInterval(loadStats, 5000);