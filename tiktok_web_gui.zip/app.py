import os
import subprocess
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory

APP_DIR = Path(__file__).resolve().parent
GUI_DIR = APP_DIR / "gui"

app = Flask(__name__, static_folder=str(GUI_DIR), static_url_path="")

bot_process = None


ACCOUNTS = {
    "1": "minhanhbg9866",
    "2": "thamvongnhungluoibieng9x",
    "3": "lammyjqjco2",
}


@app.route("/")
def index():
    return send_from_directory(GUI_DIR, "index.html")


@app.route("/api/accounts")
def accounts():
    return jsonify(ACCOUNTS)


@app.route("/api/topics")
def topics():
    folders_dir = APP_DIR / "folders"
    folders_dir.mkdir(exist_ok=True)

    topics = []
    for item in folders_dir.iterdir():
        if item.is_dir():
            topics.append(item.name)

    return jsonify(sorted(topics))


@app.route("/api/status")
def status():
    running = bot_process is not None and bot_process.poll() is None
    return jsonify({"running": running})


@app.route("/api/start", methods=["POST"])
def start():
    global bot_process

    data = request.json or {}

    account = str(data.get("account", "")).strip()
    topic = str(data.get("topic", "")).strip()
    wait_seconds = str(data.get("wait_seconds", "")).strip()

    if not account:
        return jsonify({"ok": False, "message": "Bạn chưa chọn nick TikTok"}), 400

    if not topic:
        return jsonify({"ok": False, "message": "Bạn chưa chọn folder chủ đề"}), 400

    if not wait_seconds.isdigit():
        return jsonify({"ok": False, "message": "Khoảng cách phải là số giây"}), 400

    topic_path = APP_DIR / "folders" / topic
    if not topic_path.exists():
        return jsonify({"ok": False, "message": f"Không thấy folder: {topic}"}), 400

    if bot_process is not None and bot_process.poll() is None:
        return jsonify({"ok": False, "message": "Bot đang chạy rồi"}), 400

    env = os.environ.copy()
    env["SELECTED_ACCOUNT"] = account
    env["SELECTED_TOPIC"] = topic
    env["WAIT_SECONDS"] = wait_seconds

    bot_process = subprocess.Popen(
        ["python", "vip_manager.py"],
        cwd=str(APP_DIR),
        env=env,
        creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0,
    )

    return jsonify({
        "ok": True,
        "message": f"Đã chạy bot: nick {account}, folder {topic}, cách {wait_seconds} giây"
    })


@app.route("/api/stop", methods=["POST"])
def stop():
    global bot_process

    if bot_process is None or bot_process.poll() is not None:
        return jsonify({"ok": False, "message": "Bot chưa chạy"}), 400

    bot_process.terminate()
    bot_process = None

    return jsonify({"ok": True, "message": "Đã dừng bot"})


@app.route("/api/stats")
def stats():
    topic = request.args.get("topic", "").strip()

    if not topic:
        return jsonify({
            "videos": 0,
            "pending": 0,
            "uploaded": 0,
        })

    base = APP_DIR / "folders" / topic

    def count_mp4(name):
        folder = base / name
        if not folder.exists():
            return 0
        return len([f for f in folder.iterdir() if f.is_file() and f.suffix.lower() == ".mp4"])

    return jsonify({
        "videos": count_mp4("videos"),
        "pending": count_mp4("pending"),
        "uploaded": count_mp4("uploaded"),
    })


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)